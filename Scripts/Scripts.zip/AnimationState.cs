using UnityEngine;
private enum MatchHintAnimation.AnimationState
{
    // Fields
    None = 0
    ,PreFirstInterpolation = 1
    ,Interpolate = 2
    ,PreSecondInterpolation = 3
    ,PreWait = 4
    ,WaitShort = 5
    ,Complete = 6
    ,Stop = 7
    ,StopComplete = 8
    

}
