using UnityEngine;
public enum UIEffectCapturedImage.DesamplingRate
{
    // Fields
    None = 0
    ,x1 = 1
    ,x2 = 2
    ,x4 = 4
    ,x8 = 8
    

}
