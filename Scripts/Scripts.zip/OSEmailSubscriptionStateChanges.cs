using UnityEngine;
public class OSEmailSubscriptionStateChanges
{
    // Fields
    public OSEmailSubscriptionState to;
    public OSEmailSubscriptionState from;
    
    // Methods
    public OSEmailSubscriptionStateChanges()
    {
    
    }

}
