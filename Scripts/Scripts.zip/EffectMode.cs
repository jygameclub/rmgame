using UnityEngine;
public enum UITransitionEffect.EffectMode
{
    // Fields
    Fade = 1
    ,Cutoff = 2
    ,Dissolve = 3
    

}
