using UnityEngine;
public enum LanguageSourceData.eGoogleUpdateFrequency
{
    // Fields
    Always = 0
    ,Never = 1
    ,Daily = 2
    ,Weekly = 3
    ,Monthly = 4
    ,OnlyOnce = 5
    ,EveryOtherDay = 6
    

}
