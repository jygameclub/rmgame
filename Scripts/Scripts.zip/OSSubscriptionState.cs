using UnityEngine;
public class OSSubscriptionState
{
    // Fields
    public bool userSubscriptionSetting;
    public string userId;
    public string pushToken;
    public bool subscribed;
    
    // Methods
    public OSSubscriptionState()
    {
    
    }

}
