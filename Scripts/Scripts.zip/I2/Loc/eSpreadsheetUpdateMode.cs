using UnityEngine;

namespace I2.Loc
{
    public enum eSpreadsheetUpdateMode
    {
        // Fields
        None = 0
        ,Replace = 1
        ,Merge = 2
        ,AddNewTerms = 3
        
    
    }

}
