using UnityEngine;

namespace I2.Loc
{
    public interface ILocalizationParamsManager
    {
        // Methods
        public abstract string GetParameterValue(string Param); // 0
    
    }

}
