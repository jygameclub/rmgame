using UnityEngine;

namespace I2.Loc
{
    public enum eLanguageDataFlags
    {
        // Fields
        DISABLED = 1
        ,KEEP_LOADED = 2
        ,NOT_LOADED = 4
        
    
    }

}
