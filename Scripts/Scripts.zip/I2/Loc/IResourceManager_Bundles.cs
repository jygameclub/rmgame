using UnityEngine;

namespace I2.Loc
{
    public interface IResourceManager_Bundles
    {
        // Methods
        public abstract UnityEngine.Object LoadFromBundle(string path, System.Type assetType); // 0
    
    }

}
