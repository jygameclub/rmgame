using UnityEngine;

namespace I2.Loc
{
    public class I2CustomPersistentStorage : I2BasePersistentStorage
    {
        // Methods
        public I2CustomPersistentStorage()
        {
            val_1 = new System.Object();
        }
    
    }

}
