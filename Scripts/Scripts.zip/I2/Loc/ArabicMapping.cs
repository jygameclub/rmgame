using UnityEngine;

namespace I2.Loc
{
    internal class ArabicMapping
    {
        // Fields
        public int from;
        public int to;
        
        // Methods
        public ArabicMapping(int from, int to)
        {
            this.from = from;
            this.to = to;
        }
    
    }

}
