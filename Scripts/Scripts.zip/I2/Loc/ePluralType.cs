using UnityEngine;

namespace I2.Loc
{
    public enum ePluralType
    {
        // Fields
        Zero = 0
        ,One = 1
        ,Two = 2
        ,Few = 3
        ,Many = 4
        ,Plural = 5
        
    
    }

}
