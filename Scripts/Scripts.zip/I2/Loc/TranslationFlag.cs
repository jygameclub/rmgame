using UnityEngine;

namespace I2.Loc
{
    public enum TranslationFlag
    {
        // Fields
        Normal = 1
        ,AutoTranslated = 2
        
    
    }

}
