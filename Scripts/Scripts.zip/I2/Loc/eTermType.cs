using UnityEngine;

namespace I2.Loc
{
    public enum eTermType
    {
        // Fields
        Text = 0
        ,Font = 1
        ,Texture = 2
        ,AudioClip = 3
        ,GameObject = 4
        ,Sprite = 5
        ,Material = 6
        ,Child = 7
        ,Mesh = 8
        ,TextMeshPFont = 9
        ,Object = 10
        
    
    }

}
