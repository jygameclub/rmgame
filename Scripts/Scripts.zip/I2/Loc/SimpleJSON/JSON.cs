using UnityEngine;

namespace I2.Loc.SimpleJSON
{
    public static class JSON
    {
        // Methods
        public static I2.Loc.SimpleJSON.JSONNode Parse(string aJSON)
        {
            return I2.Loc.SimpleJSON.JSONNode.Parse(aJSON:  aJSON);
        }
    
    }

}
