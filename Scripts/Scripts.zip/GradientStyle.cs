using UnityEngine;
public enum UIGradient.GradientStyle
{
    // Fields
    Rect = 0
    ,Fit = 1
    ,Split = 2
    

}
