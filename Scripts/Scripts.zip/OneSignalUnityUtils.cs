using UnityEngine;
internal class OneSignalUnityUtils
{
    // Methods
    public static string GetNewGuid()
    {
        System.Guid val_1 = System.Guid.NewGuid();
        return (string);
    }
    public OneSignalUnityUtils()
    {
    
    }

}
