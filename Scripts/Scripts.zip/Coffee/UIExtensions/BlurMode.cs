using UnityEngine;

namespace Coffee.UIExtensions
{
    public enum BlurMode
    {
        // Fields
        None = 0
        ,FastBlur = 1
        ,MediumBlur = 2
        ,DetailBlur = 3
        
    
    }

}
