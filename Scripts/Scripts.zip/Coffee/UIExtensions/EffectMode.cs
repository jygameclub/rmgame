using UnityEngine;

namespace Coffee.UIExtensions
{
    public enum EffectMode
    {
        // Fields
        None = 0
        ,Grayscale = 1
        ,Sepia = 2
        ,Nega = 3
        ,Pixel = 4
        
    
    }

}
