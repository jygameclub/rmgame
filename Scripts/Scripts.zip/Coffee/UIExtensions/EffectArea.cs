using UnityEngine;

namespace Coffee.UIExtensions
{
    public enum EffectArea
    {
        // Fields
        RectTransform = 0
        ,Fit = 1
        ,Character = 2
        
    
    }

}
