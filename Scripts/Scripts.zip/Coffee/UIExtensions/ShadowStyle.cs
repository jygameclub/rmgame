using UnityEngine;

namespace Coffee.UIExtensions
{
    public enum ShadowStyle
    {
        // Fields
        None = 0
        ,Shadow = 1
        ,Outline = 2
        ,Outline8 = 3
        ,Shadow3 = 4
        
    
    }

}
