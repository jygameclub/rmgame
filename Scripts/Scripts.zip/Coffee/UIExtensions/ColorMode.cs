using UnityEngine;

namespace Coffee.UIExtensions
{
    public enum ColorMode
    {
        // Fields
        Multiply = 0
        ,Fill = 1
        ,Add = 2
        ,Subtract = 3
        
    
    }

}
