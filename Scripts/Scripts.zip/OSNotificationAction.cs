using UnityEngine;
public class OSNotificationAction
{
    // Fields
    public string actionID;
    public OSNotificationAction.ActionType type;
    
    // Methods
    public OSNotificationAction()
    {
    
    }

}
