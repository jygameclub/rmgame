using UnityEngine;

namespace Royal.Infrastructure.UiComponents.Dialog
{
    public enum DialogManagerType
    {
        // Fields
        Home = 0
        ,Game = 1
        
    
    }

}
