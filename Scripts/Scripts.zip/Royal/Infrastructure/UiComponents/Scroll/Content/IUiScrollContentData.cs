using UnityEngine;

namespace Royal.Infrastructure.UiComponents.Scroll.Content
{
    public interface IUiScrollContentData
    {
    
    }

}
