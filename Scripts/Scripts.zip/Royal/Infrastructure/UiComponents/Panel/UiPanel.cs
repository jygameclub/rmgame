using UnityEngine;

namespace Royal.Infrastructure.UiComponents.Panel
{
    public class UiPanel : UiTouchComponent
    {
        // Methods
        public override void TouchDown(UnityEngine.Vector2 position)
        {
        
        }
        public override void TouchMove(UnityEngine.Vector2 position)
        {
        
        }
        public override void TouchUp(UnityEngine.Vector2 position)
        {
        
        }
        public override void CancelTouch(bool isTouchDisabled)
        {
        
        }
        public UiPanel()
        {
            val_1 = new UnityEngine.MonoBehaviour();
        }
    
    }

}
