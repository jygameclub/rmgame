using UnityEngine;

namespace Royal.Infrastructure.UiComponents.Button
{
    public class UiBasicButton : UiButton
    {
        // Fields
        public TMPro.TextMeshPro title;
        
        // Methods
        public UiBasicButton()
        {
            mem[1152921527528790060] = 1;
            val_1 = new UnityEngine.MonoBehaviour();
        }
    
    }

}
