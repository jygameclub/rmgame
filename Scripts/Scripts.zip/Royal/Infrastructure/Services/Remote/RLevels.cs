using UnityEngine;

namespace Royal.Infrastructure.Services.Remote
{
    [Serializable]
    public class RLevels
    {
        // Fields
        public Royal.Infrastructure.Services.Remote.RLevel[] levels;
        
        // Methods
        public RLevels()
        {
        
        }
    
    }

}
