using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class BasicInfo
    {
        // Fields
        public long event_time;
        public long user_id;
        public int is_payer;
        
        // Methods
        public BasicInfo()
        {
        
        }
    
    }

}
