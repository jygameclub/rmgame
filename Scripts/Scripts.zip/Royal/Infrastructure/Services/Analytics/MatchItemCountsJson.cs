using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class MatchItemCountsJson
    {
        // Fields
        public int blue;
        public int green;
        public int red;
        public int yellow;
        public int pink;
        
        // Methods
        public MatchItemCountsJson()
        {
        
        }
    
    }

}
