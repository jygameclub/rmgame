using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class Inventory1
    {
        // Fields
        public int rck;
        public int tnt;
        public int lb;
        public int rh;
        public int ar;
        public int ca;
        public int jh;
        public int u_rck;
        public int u_tnt;
        public int u_lb;
        
        // Methods
        public Inventory1()
        {
        
        }
    
    }

}
