using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class Inventory2
    {
        // Fields
        public int lf;
        public long ulf;
        public int st;
        public int il;
        public int cl;
        
        // Methods
        public Inventory2()
        {
        
        }
    
    }

}
