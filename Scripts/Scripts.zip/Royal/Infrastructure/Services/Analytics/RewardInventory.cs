using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class RewardInventory
    {
        // Fields
        public int r_rck;
        public int r_tnt;
        public int r_lb;
        public int r_rh;
        public int r_ar;
        public int r_ca;
        public int r_jh;
        public int ur_rck;
        public int ur_tnt;
        public int ur_lb;
        
        // Methods
        public RewardInventory()
        {
        
        }
    
    }

}
