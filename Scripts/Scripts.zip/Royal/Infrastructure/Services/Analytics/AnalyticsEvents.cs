using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class AnalyticsEvents
    {
        // Methods
        public AnalyticsEvents()
        {
        
        }
    
    }

}
