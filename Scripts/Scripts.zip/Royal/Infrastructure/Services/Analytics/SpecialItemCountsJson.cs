using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
    public class SpecialItemCountsJson
    {
        // Fields
        public int rocket_creation;
        public int tnt_creation;
        public int lb_creation;
        public int propeller_creation;
        public int rocket_use;
        public int tnt_use;
        public int lb_use;
        public int propeller_use;
        public int rocket_rocket;
        public int propeller_propeller;
        public int tnt_tnt;
        public int lb_lb;
        public int lb_tnt;
        public int lb_rocket;
        public int lb_propeller;
        public int tnt_rocket;
        public int tnt_propeller;
        public int rocket_propeller;
        
        // Methods
        public SpecialItemCountsJson()
        {
        
        }
    
    }

}
