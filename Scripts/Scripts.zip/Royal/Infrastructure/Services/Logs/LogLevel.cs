using UnityEngine;

namespace Royal.Infrastructure.Services.Logs
{
    public enum LogLevel
    {
        // Fields
        Debug = 0
        ,Error = 1
        
    
    }

}
