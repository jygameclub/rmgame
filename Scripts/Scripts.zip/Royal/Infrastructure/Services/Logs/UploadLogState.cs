using UnityEngine;

namespace Royal.Infrastructure.Services.Logs
{
    public enum UploadLogState
    {
        // Fields
        NotStarted = 0
        ,CompressStarted = 1
        ,CompressCompleted = 2
        ,UploadFunctionStarted = 3
        ,UploadFunctionCompleted = 4
        
    
    }

}
