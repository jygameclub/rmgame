using UnityEngine;

namespace Royal.Infrastructure.Services.Logs
{
    public enum FirebaseLoginState
    {
        // Fields
        UserNotLoggedIn = 0
        ,UserLoggedIn = 1
        
    
    }

}
