using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum PurchaseVerificationStatusCode
    {
        // Fields
        Verified = 0
        ,UsedBefore = 1
        ,Fail = 2
        ,VerificationNotCompleted = 3
        
    
    }

}
