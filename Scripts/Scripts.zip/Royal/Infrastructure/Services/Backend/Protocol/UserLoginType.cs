using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum UserLoginType
    {
        // Fields
        NewUser = 0
        ,OldUser = 1
        ,CloudUser = 2
        
    
    }

}
