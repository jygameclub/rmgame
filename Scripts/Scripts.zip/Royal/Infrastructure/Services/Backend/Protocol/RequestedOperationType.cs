using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum RequestedOperationType
    {
        // Fields
        None = 0
        ,ForceLog = 1
        ,WaitingUserProgressUpdate = 2
        
    
    }

}
