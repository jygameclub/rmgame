using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum UserProgressType
    {
        // Fields
        NONE = 0
        ,UpdateAreaData = 1
        ,UpdateInventoryData = 2
        ,UpdateBasicData = 3
        ,UpdateLeagueData = 4
        ,UpdateLogData = 5
        
    
    }

}
