using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum TeamActivityLevel
    {
        // Fields
        High = 0
        ,Medium = 1
        ,Low = 2
        
    
    }

}
