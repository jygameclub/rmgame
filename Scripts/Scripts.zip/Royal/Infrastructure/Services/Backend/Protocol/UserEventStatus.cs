using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum UserEventStatus
    {
        // Fields
        Continue = 0
        ,Finished = 1
        ,Claimed = 2
        
    
    }

}
