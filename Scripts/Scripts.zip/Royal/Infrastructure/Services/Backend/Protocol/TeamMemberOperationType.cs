using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum TeamMemberOperationType
    {
        // Fields
        Accept = 0
        ,Reject = 1
        ,KickUser = 2
        ,MakeLeader = 3
        ,MakeColeader = 4
        ,RemoveColeader = 5
        
    
    }

}
