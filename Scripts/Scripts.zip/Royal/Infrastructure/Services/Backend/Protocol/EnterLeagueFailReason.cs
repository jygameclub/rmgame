using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum EnterLeagueFailReason
    {
        // Fields
        None = 0
        ,LeagueIsNotActive = 1
        ,LeagueIsAboutToEnd = 2
        ,InvalidName = 3
        
    
    }

}
