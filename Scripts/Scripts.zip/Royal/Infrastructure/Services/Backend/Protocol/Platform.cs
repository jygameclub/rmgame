using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum Platform
    {
        // Fields
        IOS = 0
        ,Android = 1
        ,Editor = 2
        
    
    }

}
