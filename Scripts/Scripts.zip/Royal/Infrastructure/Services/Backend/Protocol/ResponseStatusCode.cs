using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum ResponseStatusCode
    {
        // Fields
        Success = 0
        ,Fail = 1
        
    
    }

}
