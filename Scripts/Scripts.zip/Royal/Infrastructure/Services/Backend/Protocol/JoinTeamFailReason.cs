using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum JoinTeamFailReason
    {
        // Fields
        None = 0
        ,Kicked = 1
        ,Rejected = 2
        ,Pending = 3
        
    
    }

}
