using UnityEngine;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
    public enum MadnessEventType
    {
        // Fields
        Propeller = 0
        ,TNT = 1
        ,LightBall = 2
        ,Book = 3
        
    
    }

}
