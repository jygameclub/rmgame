using UnityEngine;

namespace Royal.Infrastructure.Contexts
{
    public interface ILateContextUnit
    {
    
    }

}
