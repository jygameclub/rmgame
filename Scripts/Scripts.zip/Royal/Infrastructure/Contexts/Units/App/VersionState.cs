using UnityEngine;

namespace Royal.Infrastructure.Contexts.Units.App
{
    public enum VersionState
    {
        // Fields
        Same = 0
        ,NewInstall = 1
        ,Update = 2
        
    
    }

}
