using UnityEngine;

namespace Royal.Infrastructure.Contexts.Units.App.BackButton
{
    public interface IBackable
    {
        // Methods
        public abstract void PressBack(); // 0
    
    }

}
