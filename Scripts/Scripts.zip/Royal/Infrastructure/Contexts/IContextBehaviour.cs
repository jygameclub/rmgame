using UnityEngine;

namespace Royal.Infrastructure.Contexts
{
    public interface IContextBehaviour : IContextUnit
    {
        // Methods
        public abstract void ManualUpdate(); // 0
    
    }

}
