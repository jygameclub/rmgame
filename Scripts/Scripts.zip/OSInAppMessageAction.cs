using UnityEngine;
public class OSInAppMessageAction
{
    // Fields
    public string clickName;
    public string clickUrl;
    public bool firstClick;
    public bool closesMessage;
    
    // Methods
    public OSInAppMessageAction()
    {
    
    }

}
