using UnityEngine;
public struct GrassViewData
{
    // Fields
    public GrassSpriteData baseData;
    public GrassSpriteData patchData;
    public GrassSpriteData shadowData;
    
    // Methods
    public void Init(Royal.Scenes.Game.Mechanics.Items.StaticItems.GrassItem.View.GrassItemAssets itemAssets, Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint point, int layer)
    {
    
    }

}
