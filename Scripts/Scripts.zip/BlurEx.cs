using UnityEngine;
public enum UIEffect.BlurEx
{
    // Fields
    None = 0
    ,Ex = 1
    

}
