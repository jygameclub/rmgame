using UnityEngine;
public class OSSubscriptionStateChanges
{
    // Fields
    public OSSubscriptionState to;
    public OSSubscriptionState from;
    
    // Methods
    public OSSubscriptionStateChanges()
    {
    
    }

}
