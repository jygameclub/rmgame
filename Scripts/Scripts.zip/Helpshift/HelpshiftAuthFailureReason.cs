using UnityEngine;

namespace Helpshift
{
    public enum HelpshiftAuthFailureReason
    {
        // Fields
        AUTH_TOKEN_NOT_PROVIDED = 0
        ,INVALID_AUTH_TOKEN = 1
        
    
    }

}
