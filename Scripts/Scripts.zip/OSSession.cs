using UnityEngine;
public enum OSOutcomeEvent.OSSession
{
    // Fields
    DIRECT = 0
    ,INDIRECT = 1
    ,UNATTRIBUTED = 2
    ,DISABLED = 3
    

}
