using UnityEngine;
[Serializable]
public class SoilItemAssets.RockConfig
{
    // Fields
    public UnityEngine.Sprite[] sprites;
    public float minZAngle;
    public float maxZAngle;
    public float minScale;
    public float maxScale;
    
    // Methods
    public SoilItemAssets.RockConfig()
    {
    
    }

}
