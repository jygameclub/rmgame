using UnityEngine;
public enum OSNotification.DisplayType
{
    // Fields
    Notification = 0
    ,InAppAlert = 1
    ,None = 2
    

}
