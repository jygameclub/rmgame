using UnityEngine;

namespace DG.Tweening
{
    public static class DOTweenCYInstruction
    {
    
    }

}
