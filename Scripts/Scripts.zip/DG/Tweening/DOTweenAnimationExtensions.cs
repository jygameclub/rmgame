using UnityEngine;

namespace DG.Tweening
{
    public static class DOTweenAnimationExtensions
    {
        // Methods
        public static bool IsSameOrSubclassOf<T>(UnityEngine.Component t)
        {
            return (bool)(X0 == true) ? 1 : 0;
        }
    
    }

}
