using UnityEngine;
[Serializable]
public struct LocalizationParamsManager.ParamValue
{
    // Fields
    public string Name;
    public string Value;
    

}
