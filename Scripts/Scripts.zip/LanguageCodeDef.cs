using UnityEngine;
public struct GoogleLanguages.LanguageCodeDef
{
    // Fields
    public string Code;
    public string GoogleCode;
    public bool HasJoinedWords;
    public int PluralRule;
    

}
