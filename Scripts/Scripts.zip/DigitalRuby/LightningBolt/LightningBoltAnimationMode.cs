using UnityEngine;

namespace DigitalRuby.LightningBolt
{
    public enum LightningBoltAnimationMode
    {
        // Fields
        None = 0
        ,Random = 1
        ,Loop = 2
        ,PingPong = 3
        
    
    }

}
