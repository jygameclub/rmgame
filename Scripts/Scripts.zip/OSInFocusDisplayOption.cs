using UnityEngine;
public enum OneSignal.OSInFocusDisplayOption
{
    // Fields
    None = 0
    ,InAppAlert = 1
    ,Notification = 2
    

}
