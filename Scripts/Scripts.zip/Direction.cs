using UnityEngine;
public enum UIGradient.Direction
{
    // Fields
    Horizontal = 0
    ,Vertical = 1
    ,Angle = 2
    ,Diagonal = 3
    

}
