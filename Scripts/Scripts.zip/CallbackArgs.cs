using UnityEngine;
public struct SignInWithApple.CallbackArgs
{
    // Fields
    public UnityEngine.SignInWithApple.UserCredentialState credentialState;
    public UnityEngine.SignInWithApple.UserInfo userInfo;
    public string error;
    

}
