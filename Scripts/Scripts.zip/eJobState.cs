using UnityEngine;
public enum TranslationJob.eJobState
{
    // Fields
    Running = 0
    ,Succeeded = 1
    ,Failed = 2
    

}
