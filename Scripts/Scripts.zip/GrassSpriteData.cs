using UnityEngine;
public struct GrassSpriteData
{
    // Fields
    public UnityEngine.Sprite sprite;
    public Royal.Scenes.Game.Mechanics.Sortings.SortingData sorting;
    public UnityEngine.Color color;
    

}
