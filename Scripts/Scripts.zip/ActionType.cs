using UnityEngine;
public enum OSNotificationAction.ActionType
{
    // Fields
    Opened = 0
    ,ActionTaken = 1
    

}
