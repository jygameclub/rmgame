using UnityEngine;
private struct UiTouchListener.PinchWrapper
{
    // Fields
    public bool started;
    public Royal.Scenes.Home.Ui.Sections.Home.Pinch.IPinchable selected;
    
    // Methods
    public void CancelTouch()
    {
        if(W8 == 0)
        {
                return;
        }
    
    }
    public void Reset()
    {
        throw 36601587;
    }

}
