using UnityEngine;
public enum LanguageSourceData.eGoogleUpdateSynchronization
{
    // Fields
    Manual = 0
    ,OnSceneLoaded = 1
    ,AsSoonAsDownloaded = 2
    

}
