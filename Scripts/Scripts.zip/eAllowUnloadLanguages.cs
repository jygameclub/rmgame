using UnityEngine;
public enum LanguageSourceData.eAllowUnloadLanguages
{
    // Fields
    Never = 0
    ,OnlyInDevice = 1
    ,EditorAndDevice = 2
    

}
