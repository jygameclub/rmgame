using UnityEngine;
public class OSPermissionStateChanges
{
    // Fields
    public OSPermissionState to;
    public OSPermissionState from;
    
    // Methods
    public OSPermissionStateChanges()
    {
    
    }

}
