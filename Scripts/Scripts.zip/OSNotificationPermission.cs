using UnityEngine;
public enum OSNotificationPermission
{
    // Fields
    NotDetermined = 0
    ,Denied = 1
    ,Authorized = 2
    

}
