using UnityEngine;
public enum PersistentStorage.eFileType
{
    // Fields
    Raw = 0
    ,Persistent = 1
    ,Temporal = 2
    ,Streaming = 3
    

}
