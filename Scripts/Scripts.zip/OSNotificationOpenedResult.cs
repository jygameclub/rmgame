using UnityEngine;
public class OSNotificationOpenedResult
{
    // Fields
    public OSNotificationAction action;
    public OSNotification notification;
    
    // Methods
    public OSNotificationOpenedResult()
    {
    
    }

}
