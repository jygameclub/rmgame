using UnityEngine;
public enum AreaTaskAssets.FinalParticleSoundType
{
    // Fields
    First = 1
    ,Second = 2
    ,Third = 3
    

}
