using UnityEngine;

namespace com.adjust.sdk
{
    public enum AdjustEnvironment
    {
        // Fields
        Sandbox = 0
        ,Production = 1
        
    
    }

}
