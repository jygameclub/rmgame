using UnityEngine;
public class OSPermissionSubscriptionState
{
    // Fields
    public OSPermissionState permissionStatus;
    public OSSubscriptionState subscriptionStatus;
    public OSEmailSubscriptionState emailSubscriptionStatus;
    
    // Methods
    public OSPermissionSubscriptionState()
    {
    
    }

}
