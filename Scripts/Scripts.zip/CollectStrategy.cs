using UnityEngine;
public enum RoyalPassUnclaimedReward.CollectStrategy
{
    // Fields
    RoyalPassUnclaimed = 0
    ,Completed1000ThLevelUnclaimed = 1
    

}
