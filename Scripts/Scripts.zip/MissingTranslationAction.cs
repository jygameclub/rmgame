using UnityEngine;
public enum LanguageSourceData.MissingTranslationAction
{
    // Fields
    Empty = 0
    ,Fallback = 1
    ,ShowWarning = 2
    ,ShowTerm = 3
    

}
