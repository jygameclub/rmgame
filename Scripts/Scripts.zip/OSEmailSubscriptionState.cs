using UnityEngine;
public class OSEmailSubscriptionState
{
    // Fields
    public string emailUserId;
    public string emailAddress;
    public bool subscribed;
    
    // Methods
    public OSEmailSubscriptionState()
    {
    
    }

}
