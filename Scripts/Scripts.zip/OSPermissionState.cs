using UnityEngine;
public class OSPermissionState
{
    // Fields
    public bool hasPrompted;
    public OSNotificationPermission status;
    
    // Methods
    public OSPermissionState()
    {
    
    }

}
